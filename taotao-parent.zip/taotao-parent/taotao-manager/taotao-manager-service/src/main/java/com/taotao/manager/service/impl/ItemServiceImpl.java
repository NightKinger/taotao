package com.taotao.manager.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.taotao.common.pojo.TaoResult;
import com.taotao.manager.pojo.Item;
import com.taotao.manager.pojo.ItemDesc;
import com.taotao.manager.redis.impl.RedisUtils;
import com.taotao.manager.service.ItemDescService;
import com.taotao.manager.service.ItemService;
import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.jms.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 商品业务逻辑实现类
 */
@Service
public class ItemServiceImpl extends BaseServiceImpl<Item> implements ItemService  {

    @Autowired
    ItemDescService itemDescService;

    /**
     * 保存商品信息
     * @param item 商品信息
     * @param desc 商品描述信息
     */
    @Override
    public void saveItem(Item item, String desc) {
       Long itemid= saveXXX(item,desc);
        System.out.println("1==============="+itemid);
        /*
        *3、将新添加的商品加入到solr库中
         */
        //searchService.createAndUpdateIndex(item);
        /**
         * 告诉ActiveMQ，让他通知taotao-search去更新索引库
         */
        this.sendMessage("saveItem",itemid);
    }
    Long saveXXX(Item item, String desc)
    {
        /**
         * 1、保存商品信息到tb_item
         */
        item.setStatus(1);
        super.save(item);
        /**
         * 2、保存商品描述信息tb_item_desc
         */
        ItemDesc itemDesc=new ItemDesc();
        itemDesc.setItemDesc(desc);
        itemDesc.setItemId(item.getId());
        itemDescService.save(itemDesc);
        return  item.getId();
    }



    @Autowired
    JmsTemplate jmsTemplate;

    @Autowired
    Destination destination;


   private ObjectMapper MAPPER = new ObjectMapper();
    /**
     *
     * @param type
     * @param itemid
     */
    @Override
    public void sendMessage(String type,Long itemid)
    {
        jmsTemplate.send(destination,new MessageCreator() {
            @Override
            public Message createMessage(Session session) throws JMSException {
                TextMessage textMessage=new ActiveMQTextMessage();

                Map<String,Object> map=new HashMap<>();
                map.put("type",type);
                map.put("itemid",itemid);
                try {
                    String json=MAPPER.writeValueAsString(map);
                    System.out.println("json========="+json);
                    textMessage.setText(json);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }


                return textMessage;
            }
        });
    }

    /**
     * 分页查询商品
     *
     * @param page
     * @param rows
     * @return
     */
    @Override
    public TaoResult<Item> queryItemByPage(Integer page, Integer rows) {


        /**
         * 设置分页
         */
        PageHelper.startPage(page,rows);
        //查询所有数据
        List<Item> list=super.queryAll();
        TaoResult taoResult=new TaoResult();
        taoResult.setRows(list);
        // 获取分页插件的PageInfo
        PageInfo<Item> pageInfo = new PageInfo<>(list);
        // 设置数据总记录数
        taoResult.setTotal((int) pageInfo.getTotal());
        return taoResult;
    }

    @Autowired
    RedisUtils redisUtils;
    /**
     * 根据商品ID从缓存中查询数据
     * @param id
     * @return
     */
    @Override
    public Item queryCacheById(Long id) {
        //从redis中查询商品信息
       String itemStr= redisUtils.get("item_"+id);
       if(!StringUtils.isEmpty(itemStr))
       {
           try {
               Item item=MAPPER.readValue(itemStr,Item.class);
               System.out.println("缓存中找到商品信息：["+item+"]");
               return item;
           } catch (IOException e) {
               e.printStackTrace();
           }
       }
       Item item=super.queryById(id);
        try {
            redisUtils.set("item_"+id,MAPPER.writeValueAsString(item));
            System.out.println("从数据库中查询商品信息：["+item+"]");
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return item;
    }

}
