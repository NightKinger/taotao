package com.taotao.manager.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.taotao.manager.pojo.ItemDesc;
import com.taotao.manager.redis.impl.RedisUtils;
import com.taotao.manager.service.ItemDescService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;

@Service
public class ItemDescServiceImpl extends BaseServiceImpl<ItemDesc> implements ItemDescService {

    private ObjectMapper MAPPER = new ObjectMapper();
    @Autowired
    RedisUtils redisUtils;
    /**
     * 根据商品ID从缓存中查询数据
     * @param id
     * @return
     */
    @Override
    public ItemDesc queryCacheById(Long id) {
        //从redis中查询商品信息
        String itemStr= redisUtils.get("itemDesc_"+id);
        if(!StringUtils.isEmpty(itemStr))
        {
            try {
                ItemDesc itemDesc=MAPPER.readValue(itemStr,ItemDesc.class);
                System.out.println("从缓存中找到商品描述信息：["+itemDesc+"]");
                return itemDesc;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        ItemDesc itemDesc=super.queryById(id);
        try {
            redisUtils.set("itemDesc_"+id,MAPPER.writeValueAsString(itemDesc));
            System.out.println("从数据库中查询商品描述信息：["+itemDesc+"]");
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return itemDesc;
    }
}
