package com.taotao.manager.service.impl;

import com.github.pagehelper.PageHelper;
import com.taotao.manager.mapper.ItemCatMapper;
import com.taotao.manager.pojo.ItemCat;
import com.taotao.manager.service.ItemCatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemCatServiceImpl extends BaseServiceImpl<ItemCat> implements ItemCatService {


    /**
     * 根据商品类目父级ID查询数据
     * @param parentId
     * @return
     */

    @Override
    public List<ItemCat> queryItemCatByParentId(Long parentId) {
        /**
         * 设置查询条件
         */
        ItemCat itemCat=new ItemCat();
        itemCat.setParentId(parentId);

        List<ItemCat> list =super.queryListByWhere(itemCat);

        return list;
    }

}
