package com.taotao.manager.service.impl;

import com.github.abel533.entity.Example;
import com.github.abel533.mapper.Mapper;
import com.github.pagehelper.PageHelper;
import com.taotao.manager.pojo.BasePojo;
import com.taotao.manager.service.BaseService;
import org.springframework.beans.factory.annotation.Autowired;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Date;
import java.util.List;

public class BaseServiceImpl<T extends BasePojo> implements BaseService<T> {

    @Autowired
    private Mapper<T> mapper;

    private Class<T> clazz;

    public BaseServiceImpl() {
        // 获取父类的type
        Type type = this.getClass().getGenericSuperclass();

        // 强转为ParameterizedType，可以使用获取泛型类型的方法
        ParameterizedType pType = (ParameterizedType) type;

        // 获取泛型的class
        this.clazz = (Class<T>) pType.getActualTypeArguments()[0];
    }


    /**
     * 根据id查询数据
     *
     * @param id
     * @return
     */
    @Override
    public T queryById(Long id) {
        T t = this.mapper.selectByPrimaryKey(id);
        return t;
    }



    /**
     * 查询所有数据
     *
     * @return
     */
    @Override
    public List<T> queryAll() {
        List<T> list = this.mapper.select(null);
        return list;
    }



    /**
     * 根据条件查询数据条数
     *
     * @param t
     * @return
     */
    @Override
    public Integer queryCountByWhere(T t) {
        int count = this.mapper.selectCount(t);
        return count;
    }


    /**
     * 根据条件查询数据
     *
     * @param t
     * @return
     */
    @Override
    public List<T> queryListByWhere(T t) {
        List<T> list = this.mapper.select(t);
        return list;
    }

    /**
     * 分页查询数据
     *
     * @param page
     * @param rows
     * @return
     */
    @Override
    public List<T> queryByPage(Integer page, Integer rows) {
        PageHelper.startPage(page, rows);

        List<T> list = this.mapper.select(null);

        return list;
    }

    /**
     * 根据条件查询一条数据
     *
     * @param t
     * @return
     */
    @Override
    public T queryOne(T t) {
        T result = this.mapper.selectOne(t);
        return result;
    }

    /**
     * 新增
     *
     * @param t
     * @return
     */
    @Override
    public void save(T t) {
        if (t.getCreated() == null) {
            t.setCreated(new Date());
            t.setUpdated(t.getCreated());
        } else if (t.getUpdated() == null) {
            t.setUpdated(t.getCreated());
        }
        this.mapper.insert(t);
    }
    /**
     * 新增，忽略空参数
     *
     * @param t
     * @return
     */
    @Override
    public void saveSelective(T t) {
        this.mapper.insert(t);
    }
    /**
     * 根据主键更新
     *
     * @param t
     * @return
     */
    @Override
    public void updateById(T t) {
        // 更新方法直接设置时间
        t.setUpdated(new Date());
        this.mapper.updateByPrimaryKey(t);
    }
    /**
     * 根据主键更新，忽略空参数
     *
     * @param t
     * @return
     */
    @Override
    public void updateByIdSelective(T t) {
        // 更新方法直接设置时间
        t.setUpdated(new Date());
        this.mapper.updateByPrimaryKeySelective(t);
    }
    /**
     * 根据id删除数据
     *
     * @param id
     * @return
     */
    @Override
    public void deleteById(Long id) {
        this.mapper.deleteByPrimaryKey(id);
    }
    /**
     * 根据ids批量删除数据
     *
     * @param ids
     * @return
     */
    @Override
    public void deleteByIds(List<Object> ids) {
        // 声明条件
        Example example = new Example(this.clazz);
        example.createCriteria().andIn("id", ids);
        this.mapper.deleteByExample(example);
    }
}
