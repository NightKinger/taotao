package com.taotao.manager.service;

import com.taotao.manager.pojo.ItemDesc;

public interface ItemDescService extends  BaseService<ItemDesc> {

    /**
     * 根据商品ID从缓存中查询数据
     * @param id
     * @return
     */
    ItemDesc queryCacheById(Long id);

}
