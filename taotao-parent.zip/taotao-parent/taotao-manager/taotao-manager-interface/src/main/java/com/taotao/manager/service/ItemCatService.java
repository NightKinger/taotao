package com.taotao.manager.service;

import com.taotao.manager.pojo.ItemCat;

import java.util.List;

/**
 * 商品类目业务逻辑接口
 */
public interface ItemCatService extends BaseService<ItemCat>  {


    /**
     * 根据商品类目父级ID查询数据
     * @param parentId
     * @return
     */
    public List<ItemCat> queryItemCatByParentId(Long parentId);



}
