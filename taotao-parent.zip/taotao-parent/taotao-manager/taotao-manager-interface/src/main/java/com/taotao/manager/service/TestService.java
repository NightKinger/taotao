package com.taotao.manager.service;

/**
 * 业务逻辑实现接口
 */
public interface TestService {
    /**
     * 获取当前时间
     *
     * @return
     */
    String queryDate();
}
