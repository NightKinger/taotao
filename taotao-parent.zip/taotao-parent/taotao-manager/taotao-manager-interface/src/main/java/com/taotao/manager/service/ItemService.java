package com.taotao.manager.service;

import com.taotao.common.pojo.TaoResult;
import com.taotao.manager.pojo.Item;

public interface ItemService extends BaseService<Item> {

    /**
     * 新增商品
     * @param item 商品信息
     * @param desc 商品描述信息
     */
    void saveItem(Item item, String desc);

    /**
     * 分页查询商品
     *
     * @param page
     * @param rows
     * @return
     */
    TaoResult<Item> queryItemByPage(Integer page, Integer rows);

    /**
     * 根据商品ID从缓存中查询数据
     * @param id
     * @return
     */
    Item queryCacheById(Long id);


    /**
     * 更新索引库
     */
    void sendMessage(String type,Long itemid);


}
