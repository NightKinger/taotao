package com.taotao.manager.mapper;

/**
 * 数据访问层
 */
public interface TestMapper {

    /**
     * 从数据库获取当前时间
     * @return
     */
    String queryDate();

}
