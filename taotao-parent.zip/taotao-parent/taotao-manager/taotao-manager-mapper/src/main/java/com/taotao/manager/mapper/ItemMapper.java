package com.taotao.manager.mapper;

import com.github.abel533.mapper.Mapper;
import com.taotao.manager.pojo.Item;

/**
 * 商品数据访问类
 */
public interface ItemMapper extends Mapper<Item> {
}
