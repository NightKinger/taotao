package com.taotao.manager.mapper;

import com.github.abel533.mapper.Mapper;
import com.taotao.manager.pojo.ItemCat;

/**
 * 商品分类数据访问接口
 */
public interface ItemCatMapper extends Mapper<ItemCat> {
}
