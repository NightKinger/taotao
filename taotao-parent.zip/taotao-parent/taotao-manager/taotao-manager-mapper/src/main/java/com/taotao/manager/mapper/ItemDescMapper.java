package com.taotao.manager.mapper;

import com.github.abel533.mapper.Mapper;
import com.taotao.manager.pojo.Item;
import com.taotao.manager.pojo.ItemDesc;

/**
 * 商品描述数据访问类
 */
public interface ItemDescMapper extends Mapper<ItemDesc> {
}
