package com.taotao.amq.topic;

import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;

public class Customer2 {

    public static void main(String[] args) {



        // 1. 创建ActiveMQConnectionFactory连接工厂，需要ActiveMQ的服务地址，使用的是tcp协议
        String brokerURL = "tcp://127.0.0.1:61616";
            try {
            ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(brokerURL);

            // 2. 使用连接工厂创建连接
            Connection connection = factory.createConnection();

            // 3. 使用连接对象开启连接，使用start方法
            connection.start();

            // 4. 从连接对象里获取session
            // 第一个参数的作用是，是否提交消息
            // 第二个参数是设置应答方式，如果第一个参数是true，那么第二个参数就失效了，这里设置的应答方式是自动应答
            Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            // 5. 从session获取消息类型Destination，获取topic，（也可以获取topic，topic是订阅模式）

            Topic topic = session.createTopic("createAndUpdateSolrIndex-TOPIC");
            // 6. 从session中获取消息的消费者
            MessageConsumer consumer = session.createConsumer(topic);

            while (true) {
                // 参数表示接受消息等待的时间，单位是毫秒
                Message message = consumer.receive(200000l);
                // 如果没有消息则跳出循环
                if (message == null) {
                    break;
                }

                // 判断消息类型是TextMessage
                if (message instanceof TextMessage) {
                    // 如果是，则进行强转
                    TextMessage textMessage = (TextMessage) message;

                    // 8. 消费消息，打印消息内容
                    System.out.println("第2个消费者："+textMessage.getText());
                }
            }
            // 9. 释放资源
            consumer.close();
            session.close();
            connection.close();
        }catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

}
