package com.taotao.amq.spring;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.apache.xbean.spring.context.ClassPathXmlApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import javax.jms.*;

public class Product {

    public static void main(String[] args) {

        ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("/applicationContext-activemq.xml");

        JmsTemplate jmsTemplate=ctx.getBean(JmsTemplate.class);

        Destination destination=ctx.getBean(Destination.class);



        jmsTemplate.send(destination,new MessageCreator() {
            @Override
            public Message createMessage(Session session) throws JMSException {
                TextMessage textMessage=new ActiveMQTextMessage();
                textMessage.setText("要更新solr库了...");
                return textMessage;
            }
        });





    }
}
