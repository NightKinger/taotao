package com.taotao.amq.spring;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import java.util.Map;

/**
 * 消费者
 */
public class MyMessageListener implements MessageListener {

    private ObjectMapper MAPPER=new ObjectMapper();

    @Override
    public void onMessage(Message message) {

        TextMessage textMessage=(TextMessage)message;

        try{

            String m=textMessage.getText();

            Map<String,Object> map=MAPPER.readValue(m, Map.class);

            String type=map.get("type").toString();

            switch (type)
            {
                /**
                 * 添加商品
                 */
                case "saveItem":
                    break;
                /**
                 * 修改商品
                 */
                case "updateItem":
                    break;
                /**
                 * 删除商品
                 */
                case "deleteItem":
                    break;
            }







        }catch (Exception ex)
        {
            ex.printStackTrace();
        }



    }



}
