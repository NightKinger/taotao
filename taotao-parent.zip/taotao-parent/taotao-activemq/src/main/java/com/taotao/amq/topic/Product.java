package com.taotao.amq.topic;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTextMessage;

import javax.jms.*;

/**
 * 发送消息
 */
public class Product {

    public static void main(String[] args) {
        try {
            /**
             * 建立工厂
             */
            ActiveMQConnectionFactory activeMQConnectionFactory=new ActiveMQConnectionFactory("tcp://127.0.0.1:61616");
            /**
             * 建立生产线
             */
            Connection connection=activeMQConnectionFactory.createConnection();
            connection.start();
            /**
             * 创建会话，并指定JTA事务为false
             */
            Session session=connection.createSession(false,Session.AUTO_ACKNOWLEDGE);
            /**
             * 创建发布/订阅模式
             */
            Topic topic=session.createTopic("createAndUpdateSolrIndex-TOPIC");
            MessageProducer producer =session.createProducer(topic);
            // 7. 创建消息对象
            TextMessage textMessage = new ActiveMQTextMessage();
            // 设置消息内容
            textMessage.setText("需要更新solr库编号为:100");
            producer.send(textMessage);
            // 9. 关闭session、连接
            producer.close();
            session.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


}
