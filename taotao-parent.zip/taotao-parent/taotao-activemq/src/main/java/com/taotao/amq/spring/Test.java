package com.taotao.amq.spring;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Test {

    public static void main(String[] args) {

        ObjectMapper MAPPER = new ObjectMapper();

        Map<String,Object> map=new HashMap<>();
        map.put("type","saveItem");
        map.put("itemid",1153545);


        try {
           String json=MAPPER.writeValueAsString(map);

            System.out.println("json=="+json);


            try {
                Map maps=MAPPER.readValue(json,Map.class);
                System.out.println(maps.keySet());
            } catch (IOException e) {
                e.printStackTrace();
            }


        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }


    }
}
