package com.taotao.manager.controller;

import com.taotao.common.pojo.TaoResult;
import com.taotao.manager.pojo.Item;
import com.taotao.manager.service.ItemDescService;
import com.taotao.manager.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("item")
public class ItemController {

	@Autowired
	private ItemService itemService;

	@Autowired
	private ItemDescService itemDescService;

	// type: "POST",
	// url: "/rest/item",

	/**
	 * 新增商品
	 * 
	 * @param item
	 * @param desc
	 */
	@RequestMapping(method = RequestMethod.POST)
	// 前台Ajax对返回数据并没有使用，可以返回任何数据，返回void也可以
	// 一定要加@ResponseBody，因为Ajax的使用需要有正确的响应
	@ResponseBody
	public void saveItem(Item item, String desc) {
		this.itemService.saveItem(item, desc);
		//this.itemService.sendMessage("saveItem",item.getId());
	}

	/**
	 * 分页查询商品
	 *
	 * @param page
	 * @param rows
	 * @return
	 */
	@RequestMapping(method = RequestMethod.GET)
	@ResponseBody
	public TaoResult<Item> queryItemByPage(@RequestParam(value = "page", defaultValue = "1") Integer page,
										   @RequestParam(value = "rows", defaultValue = "30") Integer rows) {
		TaoResult<Item> taoResult = this.itemService.queryItemByPage(page, rows);

		return taoResult;
	}

}
