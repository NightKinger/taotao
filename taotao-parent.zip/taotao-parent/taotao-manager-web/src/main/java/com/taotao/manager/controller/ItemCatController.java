package com.taotao.manager.controller;

import com.taotao.manager.pojo.ItemCat;
import com.taotao.manager.service.ItemCatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("item/cat")
public class ItemCatController {

    @Autowired
    ItemCatService itemCatService;

    // {page}:相当于占位符，声明请求url中的1
    @RequestMapping("query/{page}")
    @ResponseBody
    public List<ItemCat> queryItemCat(@PathVariable Integer page, @RequestParam("row") Integer rows) {
        //List<ItemCat> list = this.itemCatService.queryItemCatByPage(page, rows);
        List<ItemCat> list = this.itemCatService.queryByPage(page, rows);
        return list;
    }

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public List<ItemCat> queryItemCatByParentId(@RequestParam(value = "id", defaultValue = "0") Long parentId) {
        List<ItemCat> list = this.itemCatService.queryItemCatByParentId(parentId);
        return list;
    }
}
